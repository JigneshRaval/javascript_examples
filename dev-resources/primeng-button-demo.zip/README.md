# How to Use

PrimeNG Issue Template is an Angular CLI project used to provide a sample test case to demonstrate a defect to help PrimeNG Team.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.