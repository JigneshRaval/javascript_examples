# jquery-consoler
a console log shower with UI display
