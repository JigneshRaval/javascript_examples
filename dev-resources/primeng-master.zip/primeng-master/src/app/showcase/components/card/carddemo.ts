import {Component,OnInit} from '@angular/core';

@Component({
    templateUrl: './carddemo.html'
})
export class CardDemo {

}