export interface FilterMetadata {
    value?: any;
    matchMode?: string;
}