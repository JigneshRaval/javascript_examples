import {Component,OnInit} from '@angular/core';

@Component({
    templateUrl: './carddemo.html',
    styleUrls: ['./carddemo.scss']
})
export class CardDemo {

}