import {Component} from '@angular/core';

@Component({
    templateUrl: './buttondemo.html',
    styleUrls: ['./buttondemo.scss']
})
export class ButtonDemo {
    
}