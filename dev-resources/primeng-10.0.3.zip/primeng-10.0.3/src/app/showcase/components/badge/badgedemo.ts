import {Component} from '@angular/core';

@Component({
    templateUrl: './badgedemo.html',
    styleUrls: ['./badgedemo.scss']
})
export class BadgeDemo {

}