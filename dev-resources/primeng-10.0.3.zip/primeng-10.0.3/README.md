
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![npm version](https://badge.fury.io/js/primeng.svg)](https://badge.fury.io/js/primeng)
[![Build Status](https://travis-ci.org/primefaces/primeng.svg?branch=master)](https://travis-ci.org/primefaces/primeng)

[![PrimeNG Hero](https://www.primefaces.org/wp-content/uploads/2020/08/primeng-release-x-fix-2.jpg)](https://www.primefaces.org/primeng)

### Website

Visit the [PrimeNG Website](https://www.primefaces.org/primeng/) for general information, demos and documentation.
