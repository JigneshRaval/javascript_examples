//main entry point
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {DashboardModule} from './dashboard';

platformBrowserDynamic().bootstrapModule(DashboardModule)