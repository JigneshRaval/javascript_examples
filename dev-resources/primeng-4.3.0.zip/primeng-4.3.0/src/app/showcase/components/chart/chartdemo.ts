import {Component} from '@angular/core';

@Component({
    templateUrl: './chartdemo.html'
})
export class ChartDemo {
    
}