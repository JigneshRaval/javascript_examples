import {Component} from '@angular/core';

@Component({
    templateUrl: './paginatordemo.html'
})
export class PaginatorDemo {

}