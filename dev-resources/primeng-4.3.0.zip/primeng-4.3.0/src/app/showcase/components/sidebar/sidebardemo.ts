import {Component} from '@angular/core';

@Component({
    templateUrl: './sidebardemo.html'
})
export class SidebarDemo {

    visibleSidebar1;
    
    visibleSidebar2;
    
    visibleSidebar3;
    
    visibleSidebar4;
    
    visibleSidebar5;
}