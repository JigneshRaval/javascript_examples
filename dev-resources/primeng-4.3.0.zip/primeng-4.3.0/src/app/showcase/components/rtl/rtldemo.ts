import {Component} from '@angular/core';

@Component({
    templateUrl: './rtldemo.html'
})
export class RTLDemo {

    visible: boolean;
}