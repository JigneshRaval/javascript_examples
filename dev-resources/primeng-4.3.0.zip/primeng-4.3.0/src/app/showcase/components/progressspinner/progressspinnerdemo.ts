import {Component,OnInit} from '@angular/core';

@Component({
    templateUrl: './progressspinnerdemo.html'
})
export class ProgressSpinnerDemo {

}