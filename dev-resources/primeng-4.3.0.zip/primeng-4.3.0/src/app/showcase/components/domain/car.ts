export interface Car {
    vin?;
    year?;
    brand?;
    color?;
    price?;
    saleDate?;
}