import {Component} from '@angular/core';

@Component({
    templateUrl: './inputtextareademo.html'
})
export class InputTextareaDemo {

}