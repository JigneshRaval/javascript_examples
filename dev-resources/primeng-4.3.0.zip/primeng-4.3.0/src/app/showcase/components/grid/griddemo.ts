import {Component} from '@angular/core';

@Component ({
    styles:[`
        .ui-g div {
            background-color: #ededed;
            text-align: center;
            border: 1px solid #fafafa;
        }
    `],
    templateUrl: './griddemo.html'
})
export class GridDemo {

}