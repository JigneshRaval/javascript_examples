import {Component} from '@angular/core';

@Component({
    templateUrl: './inputgroupdemo.html'
})
export class InputGroupDemo {

}