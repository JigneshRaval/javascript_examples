import {Component} from '@angular/core';

@Component({
    templateUrl: './fieldsetdemo.html'
})
export class FieldsetDemo {

}