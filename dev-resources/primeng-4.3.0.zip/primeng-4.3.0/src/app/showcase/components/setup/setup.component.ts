import {Component} from '@angular/core';

@Component({
    templateUrl: './setup.component.html'
})
export class SetupComponent {

}