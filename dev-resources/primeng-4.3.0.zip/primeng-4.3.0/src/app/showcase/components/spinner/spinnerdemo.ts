import {Component} from '@angular/core';

@Component({
    templateUrl: './spinnerdemo.html'
})
export class SpinnerDemo {

    val1: number;

    val2: number;

    val3: number;

    val4: number = 100;
}