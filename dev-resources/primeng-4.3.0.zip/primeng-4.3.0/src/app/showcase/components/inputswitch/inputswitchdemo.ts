import {Component} from '@angular/core';

@Component({
    templateUrl: './inputswitch.html'
})
export class InputSwitchDemo {

    checked1: boolean = false;

    checked2: boolean = true;
}