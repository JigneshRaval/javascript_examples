import {Component} from '@angular/core';

@Component({
    templateUrl: './menumodeldemo.html'
})
export class MenuModelDemo {

}