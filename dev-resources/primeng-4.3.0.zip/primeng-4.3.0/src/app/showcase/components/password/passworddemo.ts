import {Component} from '@angular/core';

@Component({
    templateUrl: './passworddemo.html'
})
export class PasswordDemo {

}