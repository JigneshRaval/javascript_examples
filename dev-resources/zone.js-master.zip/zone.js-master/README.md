# Zone.js

## The `zone.js repo` has been moved to `angular mono repo` [here](https://github.com/angular/angular/tree/master/packages/zone.js), This repo has been archived. Please create issue in angular repo. Thanks!