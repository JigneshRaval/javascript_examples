// Change default symbol prefix for testing to ensure no hard-coded references.
(window as any)['__Zone_symbol_prefix'] = '_test__';
