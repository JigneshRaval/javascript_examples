// Change default symbol prefix for testing to ensure no hard-coded references.
(global as any)['__Zone_symbol_prefix'] = '__zone_symbol_test__';
