export class Flight {
}
